# https://www.robotstxt.org/robotstxt.html
User-agent: *
Disallow:
