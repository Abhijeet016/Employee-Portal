import React from "react";
import Header from "../Header";
import Sidebar from "../Sidebar";



const Connectcomp = () =>{


return (
    <React.Fragment>
<Header></Header>
<Sidebar></Sidebar>
</React.Fragment>
)
}

export default Connectcomp;